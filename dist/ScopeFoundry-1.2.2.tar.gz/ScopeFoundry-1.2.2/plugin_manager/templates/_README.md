ScopeFoundryHW.$MODULE_NAME
===========================

ScopeFoundry hardware plug-in to control $COMPANY $MODEL

ScopeFoundry is a Python platform for controlling custom laboratory 
experiments and visualizing scientific data

<http://www.scopefoundry.org>

This software is not made by or endorsed by the device manufacturer


Author
----------

$AUTHORS_SPLIT_NEWLINE

Requirements
------------

	* ScopeFoundry

Install dll from ????

	
History
--------

### 0.1.0	YYYY-MM-DD	Initial public release.

Plug-in has been used internally and has been stable.

from ScopeFoundry import BaseApp

app = BaseApp([])

app.setup_console_widget()

app.console_widget.show()

app.exec_()